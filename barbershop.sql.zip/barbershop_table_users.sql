
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `email`, `password`) VALUES
(11, 'adampolgar5@gmail.com', '$2y$10$mfHA3sWr7bY/ICtrBejn6eOorVQyY.ki3p9KYjzRanCm5uF0hL1Pm');
